By default pressing "E" aligns cards to a grid but only once when you press it.

This mod changes it so that when you press E the grid shows up and desn't goes away until you press E again or exit to the main menu. All the cards get aligned to the grid indefinitely.

Recommended to use with the [Fix Grid mod](https://stacklands.thunderstore.io/package/benediktwerner/FixGrid/).

## Suggestions and bug reports 
Report bugs and suggestions to [me on discord (lopidav#5797)](https://discord.com/users/357116721812865025).